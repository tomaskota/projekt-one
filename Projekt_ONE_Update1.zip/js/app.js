const KEY='projektOneData';
let db=JSON.parse(localStorage.getItem(KEY)||'null');
if(!db){
 const old=localStorage.getItem('weight')||localStorage.getItem('po_weight')||92;
 db={profile:{start:92,goal:84,current:parseFloat(old)},checks:{}};
}
today.textContent=new Date().toLocaleDateString('cs-CZ',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
function save(){localStorage.setItem(KEY,JSON.stringify(db));}
function draw(){
weight.value=db.profile.current;
weightLabel.textContent='Aktuální váha: '+db.profile.current+' kg';
let p=((92-db.profile.current)/8)*100;p=Math.max(0,Math.min(100,p));
bar.style.width=p+'%';
document.querySelectorAll('input[type=checkbox]').forEach(c=>{
 c.checked=!!db.checks[c.id];
 c.onchange=()=>{db.checks[c.id]=c.checked;save();}
});
}
saveBtn.onclick=()=>{db.profile.current=parseFloat(weight.value)||db.profile.current;save();draw();}
draw();
